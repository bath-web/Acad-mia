-- Academia EDS — tables de synchronisation (site + application)
-- À coller dans Supabase : SQL Editor > New query > Run. Sans danger si lancé deux fois.

create table if not exists edsx_state (
  key text primary key,
  value jsonb not null default 'null'::jsonb,
  version bigint not null default 1,
  updated_at timestamptz not null default now()
);
alter table edsx_state add column if not exists version bigint not null default 1;

create table if not exists edsx_files (
  id text primary key,
  kind text not null default 'str',
  data text not null,
  created_at timestamptz not null default now()
);

create table if not exists edsx_ie_users (
  id bigint primary key,
  data jsonb not null,
  updated_at timestamptz not null default now()
);

create table if not exists edsx_ie_msgs (
  id bigint primary key,
  conv text,
  data jsonb not null,
  updated_at timestamptz not null default now()
);
alter table edsx_ie_msgs alter column id drop identity if exists;

create index if not exists edsx_ie_users_upd on edsx_ie_users (updated_at, id);
create index if not exists edsx_ie_msgs_upd on edsx_ie_msgs (updated_at, id);

create or replace function edsx_touch() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;
drop trigger if exists edsx_ie_users_touch on edsx_ie_users;
create trigger edsx_ie_users_touch before insert or update on edsx_ie_users for each row execute function edsx_touch();
drop trigger if exists edsx_ie_msgs_touch on edsx_ie_msgs;
create trigger edsx_ie_msgs_touch before insert or update on edsx_ie_msgs for each row execute function edsx_touch();

alter table edsx_state enable row level security;
alter table edsx_files enable row level security;
alter table edsx_ie_users enable row level security;
alter table edsx_ie_msgs enable row level security;

drop policy if exists edsx_state_all on edsx_state;
drop policy if exists edsx_files_all on edsx_files;
drop policy if exists edsx_ie_users_all on edsx_ie_users;
drop policy if exists edsx_ie_msgs_all on edsx_ie_msgs;
create policy edsx_state_all on edsx_state for all to anon, authenticated using (true) with check (true);
create policy edsx_files_all on edsx_files for all to anon, authenticated using (true) with check (true);
create policy edsx_ie_users_all on edsx_ie_users for all to anon, authenticated using (true) with check (true);
create policy edsx_ie_msgs_all on edsx_ie_msgs for all to anon, authenticated using (true) with check (true);

grant select, insert, update, delete on edsx_state, edsx_files, edsx_ie_users, edsx_ie_msgs to anon, authenticated;
